This is the mounted folder from the host.

